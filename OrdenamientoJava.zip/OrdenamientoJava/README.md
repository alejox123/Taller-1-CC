# Taller Algoritmos de Ordenamiento — Proyecto Java (MVC)

Implementación en Java de los 5 algoritmos pedidos en el taller, organizada
con patrón **MVC**, lista para importar en **Eclipse**.

## Estructura (MVC)

```
OrdenamientoJava/
├── .project / .classpath        (proyecto de Eclipse)
├── src/
│   ├── Main.java                 → arranca la aplicación
│   ├── modelo/                   → MODELO: algoritmos, datos, generación
│   │   ├── IOrdenador.java           interfaz común (Strategy)
│   │   ├── BubbleSort.java
│   │   ├── ShellSort.java
│   │   ├── QuickSort.java
│   │   ├── RadixSort.java
│   │   ├── BinaryTreeSort.java
│   │   ├── GeneradorArreglos.java    genera los arreglos aleatorios
│   │   └── ResultadoPrueba.java      fila de resultados (Algoritmo, N, Tiempo, Caso)
│   ├── vista/                    → VISTA: entrada/salida por consola
│   │   └── VistaConsola.java
│   └── controlador/              → CONTROLADOR: orquesta modelo y vista
│       └── ControladorOrdenamiento.java
```

## Cómo importar en Eclipse

1. `File > Import... > General > Existing Projects into Workspace`.
2. Selecciona la carpeta `OrdenamientoJava` (la que contiene `.project`).
3. Ejecuta `Main.java` como "Java Application".

## Cómo se ejecuta

Al correr `Main`, aparece un menú:

1. **Ejecutar pruebas con los tamaños del taller** → corre automáticamente
   los 5 algoritmos para N = 3.000 / 30.000 / 300.000 / 3.000.000 / 30.000.000,
   midiendo mejor, peor y caso promedio para cada combinación, y exporta
   todo a `resultados.csv` (en la raíz del proyecto).
2. **Tamaños personalizados** → útil para probar con valores más pequeños
   mientras se depura, sin esperar las corridas grandes.
3. **Salir**.

El archivo `resultados.csv` queda listo para abrir en Excel y generar ahí
las gráficas de línea (peor/promedio/mejor vs. tamaño de entrada) que pide
el punto 5 del taller.

## Decisiones de diseño importantes

- **Orden descendente**: los 5 algoritmos ordenan de mayor a menor
  directamente (no ordenan ascendente y luego invierten), tal como lo pide
  el enunciado.
- **Definición de mejor/peor/promedio** (misma metodología para los 5
  algoritmos, usando siempre el mismo conjunto base de números aleatorios,
  como exige el taller):
  - *Mejor caso*: el arreglo ya viene ordenado descendente (el orden buscado).
  - *Peor caso*: el arreglo viene ordenado ascendente (justo al revés).
  - *Caso promedio*: el arreglo aleatorio original, sin ningún orden.

  Nota académica: para QuickSort el peor caso teórico depende de cómo se
  elige el pivote, no solo del orden inicial de los datos; por eso esta
  implementación usa **pivote aleatorio**, así que en la práctica no debería
  degradarse a O(n²) ni siquiera con el "peor caso" definido arriba. Vale la
  pena mencionar esto en las respuestas del informe (pregunta b/c/d).
- **RadixSort** solo admite enteros no negativos; por eso
  `GeneradorArreglos` siempre genera valores en `[0, 1.000.000)`.
- **QuickSort**: pivote aleatorio + recursión solo sobre la partición más
  pequeña (y ciclo sobre la más grande), para acotar la pila a O(log n) y
  poder ordenar arreglos de hasta 30 millones de elementos sin
  `StackOverflowError`.
- **BinaryTreeSort**: inserción y recorrido **iterativos** (con pila propia
  en vez de recursión de Java), por la misma razón: con datos aleatorios el
  árbol puede desbalancearse y una versión recursiva se quedaría sin pila
  para N grandes. Los valores repetidos se cuentan dentro del mismo nodo en
  vez de crear nodos duplicados.

## Advertencia sobre tiempos de ejecución

Los algoritmos **O(n²)** (BubbleSort y, en menor medida, ShellSort) pueden
tardar **horas** con N = 3.000.000 o 30.000.000. Se recomienda:
- Ejecutar primero con la opción 2 (tamaños personalizados) usando valores
  pequeños para validar que todo funciona.
- Para las pruebas grandes del punto 4, considerar correrlas por separado
  (algoritmo por algoritmo) o dejarlas corriendo en background, y documentar
  en el informe si algún caso no se pudo completar en un tiempo razonable
  (esto también es información válida para responder la pregunta "¿cuál
  algoritmo es el menos eficiente?").
- Aumentar la memoria del JVM si es necesario: `-Xmx4g` (o más) en los
  argumentos de ejecución de Eclipse, ya que un arreglo de 30.000.000 de
  `int` ocupa ~120 MB, y BinaryTreeSort además construye un árbol de nodos
  que consume bastante más memoria que eso.
