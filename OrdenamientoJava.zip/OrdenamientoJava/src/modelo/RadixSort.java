package modelo;

/**
 * Ordenamiento Radix (Radix Sort, LSD - Least Significant Digit) - orden DESCENDENTE.
 *
 * IMPORTANTE: esta implementación solo funciona correctamente con enteros
 * NO NEGATIVOS (por eso GeneradorArreglos siempre genera valores >= 0).
 *
 * Estrategia: se ordena de forma ascendente dígito por dígito usando
 * Counting Sort de manera estable (de la técnica clásica LSD Radix Sort) y,
 * al final, se invierte el arreglo para dejarlo en orden descendente. La
 * inversión final es O(n) y no afecta la complejidad general del algoritmo.
 *
 * Complejidad: O(d * (n + b)) donde d = cantidad de dígitos del valor máximo
 * y b = base utilizada (10 en este caso). Al no depender de comparaciones,
 * Radix Sort no tiene "mejor/peor/promedio" en el sentido clásico: su tiempo
 * depende del rango de los datos, no de su orden inicial. Aun así, el taller
 * pide medir los 3 casos (mejor/peor/promedio) sobre las mismas 3 variantes
 * de arreglo que los demás algoritmos, así que se miden igualmente.
 */
public class RadixSort implements IOrdenador {

    @Override
    public void ordenar(int[] arreglo) {
        if (arreglo.length == 0) {
            return;
        }

        int max = obtenerMaximo(arreglo);

        // Counting sort ascendente para cada posición decimal (unidades, decenas, ...)
        for (long exp = 1; max / exp > 0; exp *= 10) {
            countingSortPorDigito(arreglo, exp);
        }

        invertir(arreglo); // ascendente -> descendente
    }

    private int obtenerMaximo(int[] arreglo) {
        int max = arreglo[0];
        for (int valor : arreglo) {
            if (valor > max) {
                max = valor;
            }
        }
        return max;
    }

    private void countingSortPorDigito(int[] arreglo, long exp) {
        int n = arreglo.length;
        int[] salida = new int[n];
        int[] conteo = new int[10];

        for (int i = 0; i < n; i++) {
            int digito = (int) ((arreglo[i] / exp) % 10);
            conteo[digito]++;
        }

        for (int i = 1; i < 10; i++) {
            conteo[i] += conteo[i - 1];
        }

        for (int i = n - 1; i >= 0; i--) {
            int digito = (int) ((arreglo[i] / exp) % 10);
            salida[conteo[digito] - 1] = arreglo[i];
            conteo[digito]--;
        }

        System.arraycopy(salida, 0, arreglo, 0, n);
    }

    private void invertir(int[] a) {
        int izq = 0, der = a.length - 1;
        while (izq < der) {
            int tmp = a[izq];
            a[izq] = a[der];
            a[der] = tmp;
            izq++;
            der--;
        }
    }

    @Override
    public String getNombre() {
        return "RadixSort";
    }
}
