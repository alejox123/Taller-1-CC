package modelo;

/**
 * Ordenamiento Shell (Shell Sort) - orden DESCENDENTE.
 * Usa la secuencia de saltos clásica n/2, n/4, ..., 1.
 * Complejidad: depende de la secuencia de gaps; con esta secuencia,
 * en el peor caso es O(n^2) y en la práctica es notablemente mejor que Bubble Sort.
 */
public class ShellSort implements IOrdenador {

    @Override
    public void ordenar(int[] arreglo) {
        int n = arreglo.length;
        for (int gap = n / 2; gap > 0; gap /= 2) {
            for (int i = gap; i < n; i++) {
                int actual = arreglo[i];
                int j = i;
                // Inserción con salto "gap", en orden descendente
                while (j >= gap && arreglo[j - gap] < actual) {
                    arreglo[j] = arreglo[j - gap];
                    j -= gap;
                }
                arreglo[j] = actual;
            }
        }
    }

    @Override
    public String getNombre() {
        return "ShellSort";
    }
}
