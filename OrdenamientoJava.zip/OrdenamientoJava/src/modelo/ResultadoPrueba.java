package modelo;

/**
 * Representa una fila de la tabla de resultados solicitada en el taller:
 * Algoritmo | Cantidad de Datos | Tiempo de Ejecución | Caso
 */
public class ResultadoPrueba {

    private final String algoritmo;
    private final int cantidadDatos;
    private final String caso; // "Mejor", "Peor" o "Promedio"
    private final long tiempoMs;

    public ResultadoPrueba(String algoritmo, int cantidadDatos, String caso, long tiempoMs) {
        this.algoritmo = algoritmo;
        this.cantidadDatos = cantidadDatos;
        this.caso = caso;
        this.tiempoMs = tiempoMs;
    }

    public String getAlgoritmo() {
        return algoritmo;
    }

    public int getCantidadDatos() {
        return cantidadDatos;
    }

    public String getCaso() {
        return caso;
    }

    public long getTiempoMs() {
        return tiempoMs;
    }

    /** Línea en formato CSV: Algoritmo,CantidadDatos,TiempoMs,Caso */
    public String toCsv() {
        return algoritmo + "," + cantidadDatos + "," + tiempoMs + "," + caso;
    }

    @Override
    public String toString() {
        return String.format("%-15s | %10d | %10d ms | %-9s", algoritmo, cantidadDatos, tiempoMs, caso);
    }
}
