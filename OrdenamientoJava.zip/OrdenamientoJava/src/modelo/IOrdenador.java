package modelo;

/**
 * Contrato que deben cumplir todos los algoritmos de ordenamiento del taller.
 * Cada implementación ordena el arreglo recibido de forma DESCENDENTE
 * (de mayor a menor), tal como lo exige el enunciado del taller.
 */
public interface IOrdenador {

    /**
     * Ordena el arreglo recibido de manera descendente, modificándolo en su lugar.
     * @param arreglo arreglo de enteros a ordenar
     */
    void ordenar(int[] arreglo);

    /**
     * @return nombre legible del algoritmo (usado en reportes y en la vista)
     */
    String getNombre();
}
