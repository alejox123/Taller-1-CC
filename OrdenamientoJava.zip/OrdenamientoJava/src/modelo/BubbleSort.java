package modelo;

/**
 * Ordenamiento Burbuja (Bubble Sort) - orden DESCENDENTE.
 * Complejidad: Mejor caso O(n) (con bandera de parada temprana),
 * Peor y promedio O(n^2).
 */
public class BubbleSort implements IOrdenador {

    @Override
    public void ordenar(int[] arreglo) {
        int n = arreglo.length;
        boolean huboIntercambio;
        for (int i = 0; i < n - 1; i++) {
            huboIntercambio = false;
            for (int j = 0; j < n - 1 - i; j++) {
                if (arreglo[j] < arreglo[j + 1]) { // descendente: mayor primero
                    int tmp = arreglo[j];
                    arreglo[j] = arreglo[j + 1];
                    arreglo[j + 1] = tmp;
                    huboIntercambio = true;
                }
            }
            if (!huboIntercambio) {
                break; // el arreglo ya está ordenado, se detiene antes (mejor caso)
            }
        }
    }

    @Override
    public String getNombre() {
        return "BubbleSort";
    }
}
