package modelo;

/**
 * Binary Tree Sort - orden DESCENDENTE.
 *
 * Estrategia: se inserta cada elemento en un Árbol Binario de Búsqueda (BST)
 * y luego se recorre el árbol "derecha, raíz, izquierda" (in-order invertido),
 * lo que entrega los valores en orden descendente directamente, sin
 * necesidad de una inversión final.
 *
 * Los duplicados se controlan con un contador dentro de cada nodo en vez de
 * crear un nodo nuevo por cada repetición, para no desperdiciar memoria.
 *
 * NOTA DE DISEÑO: tanto la inserción como el recorrido se implementan de
 * forma ITERATIVA (con una pila propia) y no recursiva. Esto es necesario
 * porque, para arreglos grandes (por ejemplo N = 30.000.000) generados de
 * forma aleatoria, un árbol puede quedar muy desbalanceado (casi una lista
 * enlazada) y una implementación recursiva agotaría la pila de llamadas de
 * Java (StackOverflowError).
 *
 * Complejidad: Mejor/promedio O(n log n) con árbol razonablemente balanceado;
 * Peor caso O(n^2) cuando el árbol degenera (por ejemplo al insertar datos
 * ya ordenados), tal como ocurre con un BST clásico sin balanceo (AVL/Red-Black).
 */
public class BinaryTreeSort implements IOrdenador {

    private static final class Nodo {
        int valor;
        int repeticiones = 1;
        Nodo izquierdo;
        Nodo derecho;

        Nodo(int valor) {
            this.valor = valor;
        }
    }

    @Override
    public void ordenar(int[] arreglo) {
        if (arreglo.length == 0) {
            return;
        }

        Nodo raiz = null;
        for (int valor : arreglo) {
            raiz = insertarIterativo(raiz, valor);
        }

        int[] salida = new int[arreglo.length];
        recorrerDescendenteIterativo(raiz, salida);
        System.arraycopy(salida, 0, arreglo, 0, arreglo.length);
    }

    private Nodo insertarIterativo(Nodo raiz, int valor) {
        if (raiz == null) {
            return new Nodo(valor);
        }
        Nodo actual = raiz;
        while (true) {
            if (valor == actual.valor) {
                actual.repeticiones++;
                return raiz;
            } else if (valor < actual.valor) {
                if (actual.izquierdo == null) {
                    actual.izquierdo = new Nodo(valor);
                    return raiz;
                }
                actual = actual.izquierdo;
            } else {
                if (actual.derecho == null) {
                    actual.derecho = new Nodo(valor);
                    return raiz;
                }
                actual = actual.derecho;
            }
        }
    }

    /** Recorrido derecha -> raíz -> izquierda (in-order invertido) = orden descendente. */
    private void recorrerDescendenteIterativo(Nodo raiz, int[] salida) {
        java.util.Deque<Nodo> pila = new java.util.ArrayDeque<>();
        Nodo actual = raiz;
        int indice = 0;

        while (actual != null || !pila.isEmpty()) {
            while (actual != null) {
                pila.push(actual);
                actual = actual.derecho;
            }
            actual = pila.pop();
            for (int i = 0; i < actual.repeticiones; i++) {
                salida[indice++] = actual.valor;
            }
            actual = actual.izquierdo;
        }
    }

    @Override
    public String getNombre() {
        return "BinaryTreeSort";
    }
}
