package modelo;

import java.util.Random;

/**
 * Ordenamiento Rápido (QuickSort) - orden DESCENDENTE.
 *
 * Detalles de la implementación:
 *  - Pivote aleatorio: evita que un arreglo ya ordenado (ascendente o
 *    descendente) provoque el peor caso clásico O(n^2) de forma determinista.
 *  - Después de particionar, siempre se recorre primero (con recursión) la
 *    partición más pequeña y se continúa con un ciclo "while" sobre la más
 *    grande. Esto acota la profundidad de la pila a O(log n) en vez de O(n),
 *    lo cual es indispensable para poder ordenar arreglos grandes
 *    (por ejemplo N = 30.000.000) sin generar un StackOverflowError.
 *
 * Complejidad: Mejor y promedio O(n log n); peor caso (teórico, muy
 * improbable con pivote aleatorio) O(n^2).
 */
public class QuickSort implements IOrdenador {

    private static final Random RANDOM = new Random();

    @Override
    public void ordenar(int[] arreglo) {
        if (arreglo.length > 1) {
            quickSort(arreglo, 0, arreglo.length - 1);
        }
    }

    private void quickSort(int[] a, int inicio, int fin) {
        while (inicio < fin) {
            int p = particionar(a, inicio, fin);

            // Recursión sobre la partición más pequeña, ciclo sobre la más grande
            if (p - inicio < fin - p) {
                quickSort(a, inicio, p - 1);
                inicio = p + 1;
            } else {
                quickSort(a, p + 1, fin);
                fin = p - 1;
            }
        }
    }

    private int particionar(int[] a, int inicio, int fin) {
        int indicePivoteAleatorio = inicio + RANDOM.nextInt(fin - inicio + 1);
        intercambiar(a, indicePivoteAleatorio, fin);
        int pivote = a[fin];

        int i = inicio - 1;
        for (int j = inicio; j < fin; j++) {
            if (a[j] > pivote) { // descendente: los mayores quedan a la izquierda
                i++;
                intercambiar(a, i, j);
            }
        }
        intercambiar(a, i + 1, fin);
        return i + 1;
    }

    private void intercambiar(int[] a, int i, int j) {
        int tmp = a[i];
        a[i] = a[j];
        a[j] = tmp;
    }

    @Override
    public String getNombre() {
        return "QuickSort";
    }
}
