package modelo;

import java.util.Arrays;
import java.util.Random;

/**
 * Encargado de generar los arreglos de números aleatorios que se usan en las
 * pruebas, y de derivar a partir de un mismo conjunto base las tres variantes
 * exigidas por el taller: mejor caso, peor caso y caso promedio.
 *
 * Todos los valores generados son NO negativos (0 .. limiteSuperior) porque
 * RadixSort, tal como se implementa en este proyecto, solo funciona sobre
 * enteros no negativos.
 *
 * Definición usada para las 3 variantes (misma metodología para los 5
 * algoritmos, tal como lo pide el enunciado: "CADA PRUEBA DEBE SER CON EL
 * MISMO CONJUNTO DE NÚMEROS"):
 *   - Mejor caso  -> el arreglo ya está ordenado de forma DESCENDENTE
 *                    (el orden que se busca obtener).
 *   - Peor caso   -> el arreglo está ordenado de forma ASCENDENTE
 *                    (exactamente al revés del orden buscado).
 *   - Caso promedio -> el arreglo aleatorio original, sin ningún orden.
 */
public class GeneradorArreglos {

    private static final Random RANDOM = new Random();
    public static final int LIMITE_SUPERIOR_DEFECTO = 1_000_000;

    private GeneradorArreglos() {
        // Clase utilitaria: no se instancia
    }

    /** Genera un arreglo de n enteros aleatorios en [0, limiteSuperior). */
    public static int[] generarAleatorio(int n, int limiteSuperior) {
        int[] arreglo = new int[n];
        for (int i = 0; i < n; i++) {
            arreglo[i] = RANDOM.nextInt(limiteSuperior);
        }
        return arreglo;
    }

    /** Genera un arreglo de n enteros aleatorios en [0, 1_000_000). */
    public static int[] generarAleatorio(int n) {
        return generarAleatorio(n, LIMITE_SUPERIOR_DEFECTO);
    }

    /** A partir de un arreglo base, genera una copia ordenada DESCENDENTE (mejor caso). */
    public static int[] generarMejorCaso(int[] base) {
        int[] copia = Arrays.copyOf(base, base.length);
        Arrays.sort(copia);
        invertir(copia);
        return copia;
    }

    /** A partir de un arreglo base, genera una copia ordenada ASCENDENTE (peor caso). */
    public static int[] generarPeorCaso(int[] base) {
        int[] copia = Arrays.copyOf(base, base.length);
        Arrays.sort(copia);
        return copia;
    }

    /** Devuelve una copia independiente del arreglo base (caso promedio / aleatorio). */
    public static int[] generarCasoPromedio(int[] base) {
        return Arrays.copyOf(base, base.length);
    }

    private static void invertir(int[] a) {
        int izq = 0, der = a.length - 1;
        while (izq < der) {
            int tmp = a[izq];
            a[izq] = a[der];
            a[der] = tmp;
            izq++;
            der--;
        }
    }
}
