import controlador.ControladorOrdenamiento;
import vista.VistaConsola;

/**
 * Punto de entrada de la aplicación. Su única responsabilidad es "armar"
 * el MVC (crear la Vista y el Controlador) y arrancar la ejecución.
 */
public class Main {
    public static void main(String[] args) {
        VistaConsola vista = new VistaConsola();
        ControladorOrdenamiento controlador = new ControladorOrdenamiento(vista);
        controlador.iniciar();
    }
}
