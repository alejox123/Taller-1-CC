package controlador;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import modelo.BinaryTreeSort;
import modelo.BubbleSort;
import modelo.GeneradorArreglos;
import modelo.IOrdenador;
import modelo.QuickSort;
import modelo.RadixSort;
import modelo.ResultadoPrueba;
import modelo.ShellSort;
import vista.VistaConsola;

/**
 * Controlador: conecta la Vista con el Modelo. No conoce detalles de consola
 * (eso es de la Vista) ni cómo ordena cada algoritmo (eso es del Modelo);
 * solo coordina el flujo: generar datos -> ordenar -> medir tiempo -> reportar.
 */
public class ControladorOrdenamiento {

    /** Tamaños de N pedidos explícitamente por el enunciado del taller. */
    public static final int[] TAMANIOS_TALLER = {3_000, 30_000, 300_000, 3_000_000, 30_000_000};

    private final VistaConsola vista;
    private final List<IOrdenador> algoritmos;
    private final List<ResultadoPrueba> resultados = new ArrayList<>();

    public ControladorOrdenamiento(VistaConsola vista) {
        this.vista = vista;
        this.algoritmos = new ArrayList<>();
        this.algoritmos.add(new BubbleSort());
        this.algoritmos.add(new ShellSort());
        this.algoritmos.add(new QuickSort());
        this.algoritmos.add(new RadixSort());
        this.algoritmos.add(new BinaryTreeSort());
    }

    public void iniciar() {
        vista.mostrarBienvenida();
        boolean continuar = true;
        while (continuar) {
            int opcion = vista.mostrarMenuYLeerOpcion();
            switch (opcion) {
                case 1:
                    ejecutarPruebas(TAMANIOS_TALLER);
                    exportarCsv("resultados.csv");
                    break;
                case 2:
                    int[] tamanios = vista.leerTamaniosPersonalizados();
                    ejecutarPruebas(tamanios);
                    exportarCsv("resultados.csv");
                    break;
                case 3:
                    continuar = false;
                    break;
                default:
                    vista.mostrarMensaje("Opción inválida.");
            }
        }
        vista.mostrarMensaje("¡Hasta luego!");
        vista.cerrar();
    }

    /**
     * Ejecuta, para cada algoritmo y cada tamaño N, las pruebas de mejor,
     * peor y caso promedio, usando siempre el MISMO conjunto base de números
     * aleatorios (tal como lo exige el enunciado), y guarda cada medición.
     */
    public void ejecutarPruebas(int[] tamanios) {
        for (int n : tamanios) {
            vista.mostrarMensaje("");
            vista.mostrarMensaje("=== N = " + n + " ===");

            // Un único conjunto base de números aleatorios para este N,
            // compartido por los 3 casos y por los 5 algoritmos.
            int[] base = GeneradorArreglos.generarAleatorio(n);
            int[] mejorCasoBase = GeneradorArreglos.generarMejorCaso(base);
            int[] peorCasoBase = GeneradorArreglos.generarPeorCaso(base);

            for (IOrdenador algoritmo : algoritmos) {
                medirYRegistrar(algoritmo, mejorCasoBase, n, "Mejor");
                medirYRegistrar(algoritmo, peorCasoBase, n, "Peor");
                medirYRegistrar(algoritmo, base, n, "Promedio");
            }
        }
        vista.mostrarResultados(resultados);
    }

    private void medirYRegistrar(IOrdenador algoritmo, int[] arregloBase, int n, String caso) {
        // Se clona el arreglo porque cada algoritmo ordena "en el lugar"
        // (in-place) y no debe modificar el arreglo base compartido.
        int[] copia = Arrays.copyOf(arregloBase, arregloBase.length);

        vista.mostrarProgreso(algoritmo.getNombre() + " - caso " + caso + " (N=" + n + ")...");

        long inicio = System.nanoTime();
        algoritmo.ordenar(copia);
        long fin = System.nanoTime();

        long tiempoMs = (fin - inicio) / 1_000_000;
        resultados.add(new ResultadoPrueba(algoritmo.getNombre(), n, caso, tiempoMs));
    }

    public List<ResultadoPrueba> getResultados() {
        return resultados;
    }

    /** Exporta todos los resultados acumulados a un archivo CSV, para graficar en Excel u otra herramienta. */
    public void exportarCsv(String rutaArchivo) {
        try (FileWriter escritor = new FileWriter(rutaArchivo)) {
            escritor.write("Algoritmo,CantidadDatos,TiempoMs,Caso\n");
            for (ResultadoPrueba r : resultados) {
                escritor.write(r.toCsv() + "\n");
            }
            vista.mostrarMensaje("Resultados exportados a: " + rutaArchivo);
        } catch (IOException e) {
            vista.mostrarMensaje("No se pudo exportar el CSV: " + e.getMessage());
        }
    }
}
