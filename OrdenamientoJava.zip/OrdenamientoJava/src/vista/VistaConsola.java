package vista;

import java.util.List;
import java.util.Scanner;
import modelo.ResultadoPrueba;

/**
 * Vista: se encarga únicamente de mostrar información al usuario y de leer
 * su entrada por consola. No contiene lógica de ordenamiento ni de negocio
 * (esa responsabilidad es del Controlador y el Modelo).
 */
public class VistaConsola {

    private final Scanner scanner = new Scanner(System.in);

    public void mostrarBienvenida() {
        System.out.println("==================================================");
        System.out.println(" TALLER ALGORITMOS DE ORDENAMIENTO - Universidad Distrital");
        System.out.println(" Java (MVC) - BubbleSort | ShellSort | QuickSort |");
        System.out.println("              RadixSort | BinaryTreeSort");
        System.out.println("==================================================");
    }

    public int mostrarMenuYLeerOpcion() {
        System.out.println();
        System.out.println("Seleccione una opción:");
        System.out.println(" 1. Ejecutar pruebas con los tamaños del taller");
        System.out.println("    (N = 3.000 / 30.000 / 300.000 / 3.000.000 / 30.000.000)");
        System.out.println(" 2. Ejecutar pruebas con tamaños personalizados");
        System.out.println(" 3. Salir");
        System.out.print("Opción: ");
        int opcion = leerEntero();
        return opcion;
    }

    public int[] leerTamaniosPersonalizados() {
        System.out.print("¿Cuántos tamaños de N desea probar? ");
        int cantidad = leerEntero();
        int[] tamanios = new int[cantidad];
        for (int i = 0; i < cantidad; i++) {
            System.out.print("N[" + (i + 1) + "] = ");
            tamanios[i] = leerEntero();
        }
        return tamanios;
    }

    public void mostrarProgreso(String mensaje) {
        System.out.println("  -> " + mensaje);
    }

    public void mostrarResultados(List<ResultadoPrueba> resultados) {
        System.out.println();
        System.out.println("================ RESULTADOS ================");
        System.out.printf("%-15s | %10s | %13s | %-9s%n", "Algoritmo", "N", "Tiempo", "Caso");
        System.out.println("---------------------------------------------------------");
        for (ResultadoPrueba r : resultados) {
            System.out.println(r);
        }
        System.out.println("=============================================");
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    private int leerEntero() {
        while (!scanner.hasNextInt()) {
            System.out.print("Por favor ingrese un número entero válido: ");
            scanner.next();
        }
        int valor = scanner.nextInt();
        scanner.nextLine();
        return valor;
    }

    public void cerrar() {
        scanner.close();
    }
}
